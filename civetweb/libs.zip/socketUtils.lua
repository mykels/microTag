local inspect = require "inspect"
local zmq = require "lzmq"
local json = require "json"

local socketUtils = {
    _VERSION = "0.0.1"
}

function socketUtils.send(data)
    print("Connecting to socket ...")

    local context = zmq.context()

    local clientHandler, clientError = context:socket {
        zmq.REQ,
        connect = "tcp://localhost:6201"
    }

    if (clientError) then
        print("Could connect to socket, see causing exception: " .. clientError)
        return {}
    else
        print("Connected to socket on port: " .. "6201")
    end

    print("Sending data to socket : " .. inspect(data))

    clientHandler:send(json.encode(data))

    return json.decode(clientHandler:recv())
end

return socketUtils
