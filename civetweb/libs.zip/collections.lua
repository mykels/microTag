local collections = {
    _VERSION = "0.0.1"
}

function collections.map(array, func)
    local new_array = {}
    for i, v in ipairs(array) do
        new_array[i] = func(v)
    end
    return new_array
end

function collections.forEach(array, func)
    for i, v in ipairs(array) do
        func(v)
    end
end

return collections
