json = require "json"
fileUtils = require "fileUtils"

local configUtils = {
    _VERSION = "0.0.1"
}

function configUtils.load()
    local configPath = os.getenv("CIVETWEB_APP_CONF");
    configPath = string.gsub(configPath, "?", "")

    return fileUtils.read_json(configPath)
end

return configUtils
