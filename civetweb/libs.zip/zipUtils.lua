local collections = require "collections"
local fileUtils = require "fileUtils"
local stringUtils = require "stringUtils"

local zipUtils = {
    _VERSION = "0.0.1"
}

function zipUtils.compress(destination, files)
    local zipCommand = "zip -j " .. destination

    collections.forEach(files, function(filePath)
        zipCommand = zipCommand .. " " .. filePath
    end)

    fileUtils.delete_file(destination)

    local output = assert(io.popen(zipCommand))
    for outputLine in output:lines() do
        print(outputLine)
    end
end

function extract_destination_dir(destination)
    return stringUtils.sub_until_last_of(destination, '/')
end

function zipUtils.uncompress(zipFile)
    local unzipCommand = "unzip -o " .. zipFile .. " -d " .. extract_destination_dir(zipFile)

    print("unzip command:   ", unzipCommand)

    local output = assert(io.popen(unzipCommand))

    for outputLine in output:lines() do
        print(outputLine)
    end
end

return zipUtils
