lfs = require "lfs"
json = require "json"

local fileUtils = {
    _VERSION = "0.0.1"
}

function fileUtils.list_files(dir, pattern)
    local files = {}

    for file in lfs.dir(dir) do
        if (string.match(file, pattern)) then
            table.insert(files, file)
        end
    end

    return files
end

function fileUtils.file_exists(filePath)
    return file_exists(filePath)
end

function file_exists(filePath)
    local file = io.open(filePath, "rb")
    if file then file:close() end
    return file ~= nil
end

function fileUtils.exists(dir, pattern)
    local files = {}

    for file in lfs.dir(dir) do
        if (string.match(file, pattern)) then
            table.insert(files, file)
        end
    end

    return files
end

function fileUtils.read_lines(filePath)
    if not file_exists(filePath) then
        print("File does not exist at: " .. filePath)
        return {}
    end

    local lines = {}

    for line in io.lines(filePath) do
        table.insert(lines, line)
    end

    return lines
end

function fileUtils.read_json(filePath)
    if not file_exists(filePath) then
        print("File does not exist at: " .. filePath)
        return {}
    end

    local file = io.open(filePath, "rb")
    local content = file:read "*a"

    return json.decode(content)
end

function fileUtils.write(filePath, data)
    local file = io.open(filePath, "w+")
    file:write(data)
    file:flush()
    file:close()
end

function fileUtils.delete_file(filePath)
    if not file_exists(filePath) then
        print("File does not exist at: " .. filePath)
        return {}
    end

    os.remove(filePath)
end

function fileUtils.send_file(filePath, fileName)
    if not file_exists(filePath) then
        print("File does not exist at: " .. filePath)
        return {}
    end

    mg.write("HTTP/1.1 200 OK \r\n")
    mg.write("Content-Disposition: attachment;filename=" .. fileName .. "\r\n")
    mg.write("\r\n")

    mg.send_file(filePath)
end

return fileUtils

