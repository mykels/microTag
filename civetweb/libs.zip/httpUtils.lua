local json = require "json"

local httpUtils = {
    _VERSION = "0.0.1"
}

function wrap_response(body, success)
    local responseWrapper = {}
    responseWrapper["success"] = success
    responseWrapper["data"] = body
    return responseWrapper;
end

function httpUtils.ok(body)
    mg.write("HTTP/1.1 200 OK \r\n")
    mg.write("Cache-Control: must-revalidate, private \r\n")
    mg.write("Content-Type: application/json \r\n")
    mg.write("Access-Control-Allow-Origin: * \r\n")
    mg.write("Access-Control-Allow-Methods: DELETE,GET,HEAD,POST,PUT,OPTIONS,TRACE \r\n")
    mg.write("Access-Control-Max-Age: 900 \r\n")
    mg.write("\r\n")

    mg.write(json.encode(wrap_response(body, true)))
end

function httpUtils.err(body)
    mg.write("HTTP/1.1 200 OK \r\n")
    mg.write("Cache-Control: must-revalidate, private \r\n")
    mg.write("Content-Type: application/json \r\n")
    mg.write("Access-Control-Allow-Origin: * \r\n")
    mg.write("Access-Control-Allow-Methods: DELETE,GET,HEAD,POST,PUT,OPTIONS,TRACE \r\n")
    mg.write("Access-Control-Max-Age: 900 \r\n")
    mg.write("\r\n")

    mg.write(json.encode(wrap_response(body, false)))
end

function httpUtils.bad(body)
    mg.write("HTTP/1.1 401 OK \r\n")
    mg.write("Cache-Control: must-revalidate, private \r\n")
    mg.write("Content-Type: application/json \r\n")
    mg.write("Access-Control-Allow-Origin: * \r\n")
    mg.write("Access-Control-Allow-Methods: DELETE,GET,HEAD,POST,PUT,OPTIONS,TRACE \r\n")
    mg.write("Access-Control-Max-Age: 900 \r\n")
    mg.write("\r\n")

    mg.write(json.encode(wrap_response(body, false)))
end

return httpUtils

