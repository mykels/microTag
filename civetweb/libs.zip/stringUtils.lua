local stringUtils = {
    _VERSION = "0.0.1"
}

function stringUtils.split(str, delimiter)
    if delimiter == nil then
        delimiter = "%s"
    end

    local t = {}
    local i = 1

    for str in string.gmatch(str, "([^" .. delimiter .. "]+)") do
        t[i] = str
        i = i + 1
    end
    return t
end

function last_index_of(str, pattern)
    local i = str:match(".*" .. pattern .. "()")
    if i == nil then return nil else return i - 1 end
end

function stringUtils.last_index_of(str, pattern)
    return last_index_of(str, pattern)
end

function stringUtils.sub_until_last_of(str, pattern)
    local last_index = last_index_of(str, pattern)

    return string.sub(str, 0, last_index)
end

function stringUtils.sub_from_last_of(str, pattern)
    local last_index = last_index_of(str, pattern)

    return string.sub(str, last_index + 1, #str)
end

return stringUtils
