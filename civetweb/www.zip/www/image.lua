-------------------------------------------------------------------------
-- |                      Image Controller API                       | --
-------------------------------------------------------------------------

-- | GET /image.lua/{imageName} - get an image by name from local resource
-- | POST /image.lua/{imageName} - get an image by name from local resource
  
-------------------------------------------------------------------------


-------------------------------------------------------------------------
-- |                     Controller Dependencies                     | --
-------------------------------------------------------------------------

json = require "json"
fileUtils = require "fileUtils"

-------------------------------------------------------------------------
-- |                       Controller actions                        | --
-------------------------------------------------------------------------

function send_image()
    local imageName = string.sub(mg.request_info.path_info, 2, #mg.request_info.path_info)
    
    --    TODO: get from env
    local resourcePath = "/home/sportale/civetweb/civetweb/www/resources/"
    local imagePath = resourcePath .. "images/" .. imageName .. ".jpg"
    mg.send_file(imagePath)

end

-------------------------------------------------------------------------
-- |                      Handler Registration                       | --
-------------------------------------------------------------------------

handlers = {}

function register_hanlder(method, handler)
    handlers[method] = handler
end

register_hanlder("GET", send_image)
register_hanlder("POST", send_image)

-------------------------------------------------------------------------
-- |                    Request Management                           | --
-------------------------------------------------------------------------

handler = handlers[mg.request_info.request_method]

if (handler == nil) then
    mg.write("HTTP/1.0 400 OK\r\nContent-Type: application/text\r\n\r\n")
    mg.write("Method " .. mg.request_info.request_method .. " is not supported for this controller");
else
    handlers[mg.request_info.request_method]()
end



