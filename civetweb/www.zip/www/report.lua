-------------------------------------------------------------------------
-- |                       Report Controller API                     | --
-------------------------------------------------------------------------
 
--| GET /report.lua/report : get report by date
--| POST /report.lua/report : get report by date

-------------------------------------------------------------------------
-- |                     Controller Dependencies                     | --
-------------------------------------------------------------------------

local json = require "json"
local stringUtils = require "stringUtils"
local fileUtils = require "fileUtils"
local configUtils = require "configUtils"
local httpUtils = require "httpUtils"

-------------------------------------------------------------------------
-- |                      Handler Registration                       | --
-------------------------------------------------------------------------

handlers = {}

function register_hanlder(method, path, handler)
    if(handlers[method] == nil) then
      handlers[method] = {}
    end
    
    handlers[method][path] = handler
end

function generate_log()
  local reportNode = {}

  reportNode["date"] = os.time()
  reportNode["result"] = "HIGH EMI"
  reportNode["amp"] = math.random()
  reportNode["snr"] = math.random() + 4
  reportNode["tagId"] = "11ca3eeqw2"
  reportNode["swId"] = "G3.5-4-dev"
  reportNode["hwId"] = "ABBA07"
  reportNode["serial"] = "#6887421330000"
  reportNode["eSignature"] = "AADE1FA9208D38FBAA881BE1EFAA741E22C7BBE2B62107D6099227EDA9E6"
  
  return reportNode
  
end

function generate_report()
  local reports = {}
  local logsCount = (math.random() * 1000) % 50
  for i = 1, logsCount do
    reports[i] = generate_log()
  end
   
  return reports
  
end

function send_report() 
  httpUtils.ok(generate_report())
end

register_hanlder("GET", "/report", send_report)
register_hanlder("POST", "/report", send_report)

-------------------------------------------------------------------------
-- |                    Request Management                           | --
-------------------------------------------------------------------------

handler = handlers[mg.request_info.request_method]

function find_handler_by_method(path, method)
  methodHandlers = handlers[method]
  
  for k, v in pairs(methodHandlers) do
    if (string.find(path, k)) then
      return v 
    end 
  end

  return nil
end

if (handler == nil) then
    mg.write("HTTP/1.0 400 Bad Request\r\nContent-Type: application/text\r\n\r\n")
    mg.write("Method " .. mg.request_info.request_method .. " is not supported for this controller");
else
    local path = mg.request_info.path_info
    
    if(path == nil) then
      path = "/"
    end 
    
    local handler = find_handler_by_method(path, mg.request_info.request_method)
    
    if(handler == nil) then
       mg.write("HTTP/1.0 400 Bad Request\r\nContent-Type: application/text\r\n\r\n")
       mg.write("No matching handler is found for this route " .. inspect(handlers))
    else
      handler()  
    end 
end