-------------------------------------------------------------------------
-- |                        Logs Controller API                      | --
-------------------------------------------------------------------------

--| GET /logs.lua/logs : get logs by date
--| POST /logs.lua/logs : get logs by date

--| GET /logs.lua/download : download logs
--| POST /logs.lua/download : download logs

--| DELETE /logs.lua/logs/{logFileName} : delete log file by name

-------------------------------------------------------------------------
-- |                     Controller Dependencies                     | --
-------------------------------------------------------------------------

local json = require "json"
local fileUtils = require "fileUtils"
local stringUtils = require "stringUtils"
local configUtils = require "configUtils"
local httpUtils = require "httpUtils"
local collections = require "collections"
local zipUtils = require "zipUtils"
local inspect = require "inspect"

-------------------------------------------------------------------------
-- |                      Handler Registration                       | --
-------------------------------------------------------------------------

handlers = {}

function register_hanlder(method, path, handler)
    if (handlers[method] == nil) then
        handlers[method] = {}
    end

    handlers[method][path] = handler
end

function prepare_log_files(logFiles)
    return collections.map(logFiles, function(logFile)
        local logFileObject = {}
        logFileObject["name"] = logFile
        logFileObject["date"] = os.time()
        return logFileObject;
    end)
end

function send_log_files()
    local config = configUtils.load()
    local logPath = config["logPath"]
    local logFiles = fileUtils.list_files(logPath, "sLog")

    httpUtils.ok(prepare_log_files(fileUtils.list_files(logPath, "sLog")))
end

function delete_log()
    local lastSlashPosition = string.find(mg.request_info.path_info, "/[^/]*$")
    local logFileName = string.sub(mg.request_info.path_info, lastSlashPosition + 1)
    local config = configUtils.load()
    local logPath = config["logPath"]
    local logFilePath = logPath .. logFileName

    if (fileUtils.file_exists(logFilePath)) then
        fileUtils.delete_file(logFilePath)
        httpUtils.ok()
    else
        httpUtils.bad("File does not exist at " .. logFilePath)
    end
end

function download_logs()
    local config = configUtils.load()
    local logPath = config["logPath"]

    local lastSlashPosition = string.find(mg.request_info.path_info, "/[^/]*$")
    local logFileNamesQuery = string.sub(mg.request_info.path_info, lastSlashPosition + 1)
    local logFileNames = stringUtils.split(logFileNamesQuery, ",")

    if (#logFileNames == 1) then
        fileUtils.send_file(logPath .. logFileNames[1], logFileNames[1])
    else
        local zippedLogPath = config["zippedLogPath"]

        local full_log_paths = collections.map(logFileNames, function(logFileName)
            return logPath .. "/" .. logFileName
        end)

        zipUtils.compress(zippedLogPath, full_log_paths)

        fileUtils.send_file(zippedLogPath, "logs.zip")
    end
end


register_hanlder("GET", "/logs", send_log_files)
register_hanlder("POST", "/logs", send_log_files)

register_hanlder("DELETE", "/logs", delete_log)

register_hanlder("GET", "/download", download_logs)
register_hanlder("POST", "/download", download_logs)

register_hanlder("OPTIONS", "/logs", httpUtils.ok)

-------------------------------------------------------------------------
-- |                    Request Management                           | --
-------------------------------------------------------------------------

handler = handlers[mg.request_info.request_method]

function find_handler_by_method(path, method)
    methodHandlers = handlers[method]

    for k, v in pairs(methodHandlers) do
        if (string.find(path, k)) then
            return v
        end
    end

    return nil
end

if (handler == nil) then
    mg.write("HTTP/1.0 400 Bad Request\r\nContent-Type: application/text\r\n\r\n")
    mg.write("Method " .. mg.request_info.request_method .. " is not supported for this controller");
else
    local path = mg.request_info.path_info

    if (path == nil) then
        path = "/"
    end

    local handler = find_handler_by_method(path, mg.request_info.request_method)

    if (handler == nil) then
        mg.write("HTTP/1.0 400 Bad Request\r\nContent-Type: application/text\r\n\r\n")
        mg.write("No matching handler is found for this route " .. inspect(handlers))
    else
        handler()
    end
end
