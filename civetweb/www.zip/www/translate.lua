-------------------------------------------------------------------------
-- |                      Terminal Controller API                    | --
-------------------------------------------------------------------------

-- | GET /terminal.lua/{command} - executes command on device
-- | POST /terminal.lua/{command} - executes command on device
  
-------------------------------------------------------------------------
-- |                     Controller Dependencies                     | --
-------------------------------------------------------------------------

local json = require "json"
local configUtils = require "configUtils"
local httpUtils = require "httpUtils"

-------------------------------------------------------------------------
-- |                      Handler Registration                       | --
-------------------------------------------------------------------------

handlers = {}

function register_hanlder(method, handler)
    handlers[method] = handler
end

function sendTranslation()
    local languageLocale = string.sub(mg.request_info.path_info, 2, #mg.request_info.path_info)
    local config = configUtils.load()
    local languagesPath = config["languagePath"]
    local translationPath = languagesPath .. languageLocale .. ".json"
    
    mg.send_file(translationPath)
end

register_hanlder("GET", sendTranslation)
register_hanlder("POST", sendTranslation)

-------------------------------------------------------------------------
-- |                    Request Management                           | --
-------------------------------------------------------------------------

handler = handlers[mg.request_info.request_method]

if (handler == nil) then
    mg.write("HTTP/1.0 400 OK\r\nContent-Type: application/text\r\n\r\n")
    mg.write("Method " .. mg.request_info.request_method .. " is not supported for this controller");
else
    handlers[mg.request_info.request_method]()
end



