-------------------------------------------------------------------------
-- |                       Config Controller API                     | --
-------------------------------------------------------------------------

--| GET /config.lua/config : get config
--| POST /config.lua/config : get Config

-------------------------------------------------------------------------
-- |                     Controller Dependencies                     | --
-------------------------------------------------------------------------

local configUtils = require "configUtils"
local httpUtils = require "httpUtils"
local inspect = require "inspect"

-------------------------------------------------------------------------
-- |                      Handler Registration                       | --
-------------------------------------------------------------------------

handlers = {}

function register_hanlder(method, path, handler)
    if (handlers[method] == nil) then
        handlers[method] = {}
    end

    handlers[method][path] = handler
end

function send_config()
    httpUtils.ok(configUtils.load())
end

register_hanlder("GET", "/config", send_config)
register_hanlder("POST", "/config", send_config)

-------------------------------------------------------------------------
-- |                    Request Management                           | --
-------------------------------------------------------------------------

handler = handlers[mg.request_info.request_method]


if (handler == nil) then
    mg.write("HTTP/1.0 400 Bad Request\r\nContent-Type: application/text\r\n\r\n")
    mg.write("Method " .. mg.request_info.request_method .. " is not supported for this controller");
else
    local path = mg.request_info.path_info

    if (path == nil) then
        path = "/"
    end

    local handler = handlers[mg.request_info.request_method][path]

    if (handler == nil) then
        mg.write("HTTP/1.0 400 Bad Request\r\nContent-Type: application/text\r\n\r\n")
        mg.write("No matching handler is found for this route " .. inspect(handlers))
    else
        handlers[mg.request_info.request_method][path]()
    end
end
