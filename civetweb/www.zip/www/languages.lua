-------------------------------------------------------------------------
-- |                      Language Controller API                    | --
-------------------------------------------------------------------------

-- | GET /languages.lua - get available languages from local resource
-- | POST /languages.lua - get available languages from local resource
  
-------------------------------------------------------------------------
-- |                     Controller Dependencies                     | --
-------------------------------------------------------------------------

local json = require "json"
local stringUtils = require "stringUtils"
local fileUtils = require "fileUtils"
local configUtils = require "configUtils"
local httpUtils = require "httpUtils"

-------------------------------------------------------------------------
-- |                      Handler Registration                       | --
-------------------------------------------------------------------------

handlers = {}

function register_hanlder(method, handler)
    handlers[method] = handler
end

function sendAvailableLanguages()
    local config = configUtils.load()
    local languagesPath = config["languagePath"]
    httpUtils.ok(fileUtils.list_files(languagesPath, "json"))
end

register_hanlder("GET", sendAvailableLanguages)
register_hanlder("POST", sendAvailableLanguages)

-------------------------------------------------------------------------
-- |                    Request Management                           | --
-------------------------------------------------------------------------

handler = handlers[mg.request_info.request_method]
 
if (handler == nil) then
    mg.write("HTTP/1.0 400 OK\r\nContent-Type: application/text\r\n\r\n")
    mg.write("Method " .. mg.request_info.request_method .. " is not supported for this controller");
else
    handlers[mg.request_info.request_method]()
end