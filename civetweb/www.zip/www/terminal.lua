-------------------------------------------------------------------------
-- |                      Terminal Controller API                    | --
-------------------------------------------------------------------------

--| GET /terminal.lua/execute/{command} : executes command on device
--| POST /terminal.lua/execute/{command} : executes command on device

-------------------------------------------------------------------------
-- |                     Controller Dependencies                     | --
-------------------------------------------------------------------------

local json = require "json"
local httpUtils = require "httpUtils"
local socketUtils = require "socketUtils"
local inspect = require "inspect"

-------------------------------------------------------------------------
-- |                      Handler Registration                       | --
-------------------------------------------------------------------------

handlers = {}

function register_hanlder(method, path, handler)
    if (not handlers[method]) then
        handlers[method] = {}
    end

    handlers[method][path] = handler
end

function execute_command(command)
    local request = {}
    local data = {}

    request["task"] = "terminal"
    data["command"] = command
    request["data"] = data

    return socketUtils.send(request)
end

function handle_command_execution()
    local lastSlashPosition = string.find(mg.request_info.path_info, "/[^/]*$")
    local command = string.sub(mg.request_info.path_info, lastSlashPosition + 1)
    local commandResponse = execute_command(command)
    httpUtils.ok(commandResponse)
end

register_hanlder("GET", "/execute", handle_command_execution)
register_hanlder("POST", "/execute", handle_command_execution)

-------------------------------------------------------------------------
-- |                    Request Management                           | --
-------------------------------------------------------------------------

handler = handlers[mg.request_info.request_method]

function find_handler_by_method(path, method)
    local methodHandlers = handlers[method]

    for k, v in pairs(methodHandlers) do
        if (string.find(path, k)) then
            return v
        end
    end

    return nil
end

if (not handler) then
    mg.write("HTTP/1.0 400 Bad Request\r\nContent-Type: application/text\r\n\r\n")
    mg.write("Method " .. mg.request_info.request_method .. " is not supported for this controller");
else
    local path = mg.request_info.path_info

    if (not path) then
        path = "/"
    end

    local handler = find_handler_by_method(path, mg.request_info.request_method)

    if (not handler) then
        mg.write("HTTP/1.0 400 Bad Request\r\nContent-Type: application/text\r\n\r\n")
        mg.write("No matching handler is found for this route " .. inspect(handlers))
    else
        handler()
    end
end
