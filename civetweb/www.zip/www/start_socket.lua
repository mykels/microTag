local inspect = require "inspect"
local json = require "json"
local zmq = require "lzmq"

local task_handlers

function execute_ip_config(response)
    response["data"] = "Windows IP Configuration\n" ..
            "\n" ..
            "\n" ..
            "Ethernet adapter Local Area Connection:\n" ..
            "\n" ..
            "   Connection-specific DNS Suffix  . : Home\n" ..
            "   Link-local IPv6 Address . . . . . : fe80::a822:24b1:d261:fba5%6\n" ..
            "   IPv4 Address. . . . . . . . . . . : 10.0.0.1\n" ..
            "   Subnet Mask . . . . . . . . . . . : 255.255.255.0\n" ..
            "   Default Gateway . . . . . . . . . : 10.0.0.138\n" ..
            "\n" ..
            "Ethernet adapter VMware Network Adapter VMnet1:\n" ..
            "\n" ..
            "   Connection-specific DNS Suffix  . :\n" ..
            "   Link-local IPv6 Address . . . . . : fe80::4934:3e1f:c366:caed%19\n" ..
            "   IPv4 Address. . . . . . . . . . . : 192.168.223.1\n" ..
            "   Subnet Mask . . . . . . . . . . . : 255.255.255.0\n" ..
            "   Default Gateway . . . . . . . . . :\n" ..
            "\n" ..
            "Ethernet adapter VMware Network Adapter VMnet8:\n" ..
            "\n" ..
            "   Connection-specific DNS Suffix  . :\n" ..
            "   Link-local IPv6 Address . . . . . : fe80::e9d4:8b58:ff0e:1b55%12\n" ..
            "   IPv4 Address. . . . . . . . . . . : 192.168.132.1\n" ..
            "   Subnet Mask . . . . . . . . . . . : 255.255.255.0\n" ..
            "   Default Gateway . . . . . . . . . :\n" ..
            "\n" ..
            "Tunnel adapter isatap.Home:\n" ..
            "\n" ..
            "   Media State . . . . . . . . . . . : Media disconnected\n" ..
            "   Connection-specific DNS Suffix  . : Home\n" ..
            "\n" ..
            "Tunnel adapter Local Area Connection* 10:\n" ..
            "\n" ..
            "   Media State . . . . . . . . . . . : Media disconnected\n" ..
            "   Connection-specific DNS Suffix  . :\n" ..
            "\n" ..
            "Tunnel adapter isatap.{FAE64E76-4CE5-4E6F-9D0B-36F49FE24F6F}:\n" ..
            "\n" ..
            "   Media State . . . . . . . . . . . : Media disconnected\n" ..
            "   Connection-specific DNS Suffix  . :\n" ..
            "\n" ..
            "Tunnel adapter isatap.{BD42B3DA-2424-4F83-8A1C-9FA00FC14F1B}:\n" ..
            "\n" ..
            "   Media State . . . . . . . . . . . : Media disconnected\n" ..
            "   Connection-specific DNS Suffix  . :"

    response["success"] = "true"
    response["type"] = "text"
end

function randomInInterval(min, max)
    return math.random() * (max - min) + min;
end

function generatePoint(x, y)
    local point = {}
    point["x"] = x
    point["y"] = y
    return point
end

function generatePoints(count, pointFunc)
    local points = {}

    for i = 1, count do
        points[i] = generatePoint(i, pointFunc(i))
    end

    return points
end

function execute_chart(response, chartName)
    response["data"] = generatePoints(10, function(i)
        return math.pow(i, randomInInterval(1, 8)) + randomInInterval(1, 100)
    end)

    response["success"] = "true"
    response["type"] = "chart"
    response["chartName"] = chartName
end

function execute_help(response)
    response["data"] = "For more information on a specific command, type HELP command-name\nclear:\t  clears terminal\nchart chart-name:\t  execute measurement and paint chart\nipconfig:\t  get ip configuration of running host\n"
    response["success"] = "true"
    response["type"] = "text"
end

function execute_terminal_command(request)
    local response = {}
    local command = request["data"]["command"]

    response["command"] = command


    if (string.find(command, "ipconfig")) then
        execute_ip_config(response)
    elseif (string.find(command, "chart")) then
        local lastSpacePosition = string.find(command, " [^ ]*$")
        local chartName = string.sub(command, lastSpacePosition + 1)

        execute_chart(response, chartName)
    elseif (string.find(command, "help")) then
        execute_help(response)
    else
        response["data"] = "'" .. command .. "' is not recognized as an internal or external command"
        response["success"] = "false"
        response["type"] = "text"
    end

    return response
end

function handle_request(requestBuffer)
    local request = json.decode(requestBuffer)
    local task = request["task"]

    if (not task) then
        local response = {}
        response["success"] = "false"
        response["error"] = "request task is missing"
        return response
    elseif task_handlers[task] then
        local task_handler = task_handlers[task]
        return task_handler(request)
    else
        local response = {}
        response["success"] = "false"
        response["error"] = "request task '" .. task .. "' is unknown"
        return response
    end
end

function init_task_handlers()
    task_handlers = {}
    task_handlers["terminal"] = execute_terminal_command
end

function main()
    print("Creating socket ...")

    local context = zmq.context()

    local serverHandler, serverError = context:socket {
        zmq.REP,
        bind = "tcp://*:6201"
    }

    if (serverError) then
        print("Socket could not be initialized, see causing exception: " .. serverError)
        return {}
    else
        print("Socket is initialized on port: " .. "6201")
    end

    init_task_handlers()

    while true do
        print("Waiting for message ...")
        local request = serverHandler:recv()
        print("Received request from client: " .. inspect(request))
        serverHandler:send(json.encode(handle_request(request)))
    end
end

main()
