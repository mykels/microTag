-------------------------------------------------------------------------
-- |                       Device Controller API                     | --
-------------------------------------------------------------------------

--| GET /settings.lua/settings : get device settings
--| POST /settings.lua/settings : get device settings

--| GET /settings.lua/download : download device settings

--| POST /settings.lua/save : save device settings

-------------------------------------------------------------------------
-- |                     Controller Dependencies                     | --
-------------------------------------------------------------------------

local fileUtils = require "fileUtils"
local configUtils = require "configUtils"
local httpUtils = require "httpUtils"
local zipUtils = require "zipUtils"
local inspect = require "inspect"

-------------------------------------------------------------------------
-- |                      Handler Registration                       | --
-------------------------------------------------------------------------

handlers = {}

function register_hanlder(method, path, handler)
    if (handlers[method] == nil) then
        handlers[method] = {}
    end

    handlers[method][path] = handler
end

function send_settings()
    local config = configUtils.load()
    local settingsPath = config["settingsPath"]

    httpUtils.ok(fileUtils.read_json(settingsPath))
end

function download_settings()
    local config = configUtils.load()
    local settingsPath = config["settingsPath"]
    local zippedSettingsPath = config["zippedSettingsPath"]

    local files = {}
    table.insert(files, settingsPath)

    zipUtils.compress(zippedSettingsPath, files)

    mg.send_file(zippedSettingsPath)
end

function save_settings()
    local config = configUtils.load()
    local settingsPath = config["settingsPath"]

    fileUtils.write(settingsPath, mg.read())

    httpUtils.ok()
end

function upload_settings()
    local config = configUtils.load()
    local zippedSettingsPath = config["zippedSettingsPath"]

    local stringtab = {}

    repeat
        local add_data = mg.read()
        if add_data then
            stringtab[#stringtab + 1] = add_data
        end
    until (add_data == nil);

    local bdata = table.concat(stringtab)
    stringtab = nil

    fileUtils.write(zippedSettingsPath, bdata)

    zipUtils.uncompress(zippedSettingsPath)

    httpUtils.ok()
end

register_hanlder("GET", "/settings", send_settings)
register_hanlder("POST", "/settings", send_settings)

register_hanlder("GET", "/download", download_settings)

register_hanlder("POST", "/save", save_settings)

register_hanlder("POST", "/upload", upload_settings)
register_hanlder("OPTIONS", "/upload", httpUtils.ok)

-------------------------------------------------------------------------
-- |                    Request Management                           | --
-------------------------------------------------------------------------

handler = handlers[mg.request_info.request_method]


if (handler == nil) then
    mg.write("HTTP/1.0 400 Bad Request\r\nContent-Type: application/text\r\n\r\n")
    mg.write("Method " .. mg.request_info.request_method .. " is not supported for this controller");
else
    local path = mg.request_info.path_info

    if (path == nil) then
        path = "/"
    end

    local handler = handlers[mg.request_info.request_method][path]

    if (handler == nil) then
        mg.write("HTTP/1.0 400 Bad Request\r\nContent-Type: application/text\r\n\r\n")
        mg.write("No matching handler is found for this route " .. inspect(handlers))
    else
        handlers[mg.request_info.request_method][path]()
    end
end
